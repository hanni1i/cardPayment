package com.example.a1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import com.example.a1.shared.ui.CardPaymentScreen
import com.example.a1.shared.ui.PinkTheme
import com.example.a1.shared.viewmodel.CardPaymentViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val viewModel = remember { CardPaymentViewModel() }
            var currentTheme by remember { mutableStateOf(PinkTheme) }

            CardPaymentScreen(
                viewModel = viewModel,
                theme = currentTheme,
                onThemeSelected = { newTheme ->
                    currentTheme = newTheme
                }
            )
        }
    }
}