@echo off
cd C:\Users\user\AndroidStudioProjects\1

echo Останавливаем Gradle демоны...
gradlew --stop

echo Удаляем локальные папки build...
if exist .gradle rmdir /s /q .gradle
if exist build rmdir /s /q build
if exist androidApp\build rmdir /s /q androidApp\build
if exist shared\build rmdir /s /q shared\build

echo Удаляем глобальный кэш Gradle...
if exist %USERPROFILE%\.gradle\caches rmdir /s /q %USERPROFILE%\.gradle\caches
if exist %USERPROFILE%\.gradle\wrapper\dists rmdir /s /q %USERPROFILE%\.gradle\wrapper\dists

echo Готово!
pause