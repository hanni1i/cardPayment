@echo off
echo ========================================
echo ПОЛНАЯ ОЧИСТКА КЭША GRADLE
echo ========================================
echo.

echo [1/7] Останавливаем все Gradle демоны...
cd /d C:\Users\user\AndroidStudioProjects\2
gradlew --stop 2>nul

echo [2/7] Удаляем локальный кэш проекта...
if exist .gradle rmdir /s /q .gradle
if exist build rmdir /s /q build
if exist composeApp\build rmdir /s /q composeApp\build
if exist shared\build rmdir /s /q shared\build

echo [3/7] Удаляем глобальный кэш Gradle (версия 8.10.2)...
if exist %USERPROFILE%\.gradle\caches\8.10.2 rmdir /s /q %USERPROFILE%\.gradle\caches\8.10.2
if exist %USERPROFILE%\.gradle\caches\transforms-3 rmdir /s /q %USERPROFILE%\.gradle\caches\transforms-3
if exist %USERPROFILE%\.gradle\caches\journal-1 rmdir /s /q %USERPROFILE%\.gradle\caches\journal-1
if exist %USERPROFILE%\.gradle\caches\user-id.txt del %USERPROFILE%\.gradle\caches\user-id.txt

echo [4/7] Удаляем старые версии Gradle...
if exist %USERPROFILE%\.gradle\wrapper\dists rmdir /s /q %USERPROFILE%\.gradle\wrapper\dists

echo [5/7] Удаляем папку .idea проекта...
if exist .idea rmdir /s /q .idea

echo [6/7] Удаляем временные файлы...
del /f /s /q *.iml 2>nul
del /f /s /q local.properties 2>nul

echo [7/7] Очистка завершена!
echo.
echo ========================================
echo СЛЕДУЮЩИЕ ШАГИ:
echo ========================================
echo 1. Запустите Android Studio от имени администратора
echo 2. Откройте проект C:\Users\user\AndroidStudioProjects\2
echo 3. Нажмите File -> Settings -> Build, Execution, Deployment -> Build Tools -> Gradle
echo 4. Убедитесь, что Gradle JDK = Embedded JDK (версия 17)
echo 5. Нажмите File -> Sync Project with Gradle Files
echo 6. Дождитесь загрузки всех зависимостей
echo.
pause