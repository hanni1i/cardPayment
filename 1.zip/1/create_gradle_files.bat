@echo off
cd C:\Users\user\AndroidStudioProjects\1

echo Создаем структуру папок...
if not exist gradle mkdir gradle
if not exist gradle\wrapper mkdir gradle\wrapper

echo Создаем gradle-wrapper.properties...
(
echo distributionBase=GRADLE_USER_HOME
echo distributionPath=wrapper/dists
echo distributionUrl=https://services.gradle.org/distributions/gradle-8.5-bin.zip
echo zipStoreBase=GRADLE_USER_HOME
echo zipStorePath=wrapper/dists
) > gradle\wrapper\gradle-wrapper.properties

echo Создаем gradle-wrapper.jar...
type nul > gradle\wrapper\gradle-wrapper.jar

echo.
echo Готово! Теперь перезапустите Android Studio.
pause