@echo off
cd C:\Users\user\AndroidStudioProjects\1

echo Исправляем проблему с Gradle и иконками...
echo.

:: Шаг 1: Обновляем Gradle wrapper
echo Обновляем Gradle до версии 8.5...
echo distributionBase=GRADLE_USER_HOME > gradle\wrapper\gradle-wrapper.properties
echo distributionPath=wrapper/dists >> gradle\wrapper\gradle-wrapper.properties
echo distributionUrl=https://services.gradle.org/distributions/gradle-8.5-bin.zip >> gradle\wrapper\gradle-wrapper.properties
echo zipStoreBase=GRADLE_USER_HOME >> gradle\wrapper\gradle-wrapper.properties
echo zipStorePath=wrapper/dists >> gradle\wrapper\gradle-wrapper.properties

:: Шаг 2: Обновляем gradle.properties
echo Обновляем gradle.properties...
echo org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m > gradle.properties
echo android.useAndroidX=true >> gradle.properties
echo kotlin.code.style=official >> gradle.properties
echo org.gradle.parallel=true >> gradle.properties
echo org.gradle.caching=true >> gradle.properties
echo org.gradle.daemon=true >> gradle.properties
echo kotlin.jvm.target.validation.mode=warning >> gradle.properties

:: Шаг 3: Удаляем проблемные mipmap папки
echo Удаляем старые иконки...
if exist androidApp\src\main\res\mipmap-hdpi rmdir /s /q androidApp\src\main\res\mipmap-hdpi
if exist androidApp\src\main\res\mipmap-mdpi rmdir /s /q androidApp\src\main\res\mipmap-mdpi
if exist androidApp\src\main\res\mipmap-xhdpi rmdir /s /q androidApp\src\main\res\mipmap-xhdpi
if exist androidApp\src\main\res\mipmap-xxhdpi rmdir /s /q androidApp\src\main\res\mipmap-xxhdpi
if exist androidApp\src\main\res\mipmap-xxxhdpi rmdir /s /q androidApp\src\main\res\mipmap-xxxhdpi

:: Шаг 4: Создаем папку для drawable
if not exist androidApp\src\main\res\drawable mkdir androidApp\src\main\res\drawable

:: Шаг 5: Создаем векторную иконку
echo Создаем новую векторную иконку...
echo ^<?xml version="1.0" encoding="utf-8"?^> > androidApp\src\main\res\drawable\ic_launcher.xml
echo ^<vector xmlns:android="http://schemas.android.com/apk/res/android" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     android:width="48dp" android:height="48dp" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     android:viewportWidth="48" android:viewportHeight="48"^> >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     ^<path >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:fillColor="#2196F3" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:pathData="M0,0 L48,0 L48,48 L0,48 Z" /^> >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     ^<path >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:fillColor="#FFFFFF" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:pathData="M12,12 L36,12 L36,20 L12,20 Z" /^> >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     ^<path >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:fillColor="#FFFFFF" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:pathData="M12,24 L36,24 L36,28 L12,28 Z" /^> >> androidApp\src\main\res\drawable\ic_launcher.xml
echo     ^<path >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:fillColor="#FFFFFF" >> androidApp\src\main\res\drawable\ic_launcher.xml
echo         android:pathData="M12,32 L36,32 L36,36 L12,36 Z" /^> >> androidApp\src\main\res\drawable\ic_launcher.xml
echo ^</vector^> >> androidApp\src\main\res\drawable\ic_launcher.xml

:: Шаг 6: Создаем strings.xml если его нет
if not exist androidApp\src\main\res\values mkdir androidApp\src\main\res\values
echo ^<?xml version="1.0" encoding="utf-8"?^> > androidApp\src\main\res\values\strings.xml
echo ^<resources^> >> androidApp\src\main\res\values\strings.xml
echo     ^<string name="app_name"^>Card Payment^</string^> >> androidApp\src\main\res\values\strings.xml
echo ^</resources^> >> androidApp\src\main\res\values\strings.xml

:: Шаг 7: Обновляем AndroidManifest.xml
echo ^<?xml version="1.0" encoding="utf-8"?^> > androidApp\src\main\AndroidManifest.xml
echo ^<manifest xmlns:android="http://schemas.android.com/apk/res/android"^> >> androidApp\src\main\AndroidManifest.xml
echo. >> androidApp\src\main\AndroidManifest.xml
echo     ^<application >> androidApp\src\main\AndroidManifest.xml
echo         android:allowBackup="true" >> androidApp\src\main\AndroidManifest.xml
echo         android:icon="@drawable/ic_launcher" >> androidApp\src\main\AndroidManifest.xml
echo         android:label="@string/app_name" >> androidApp\src\main\AndroidManifest.xml
echo         android:roundIcon="@drawable/ic_launcher" >> androidApp\src\main\AndroidManifest.xml
echo         android:supportsRtl="true" >> androidApp\src\main\AndroidManifest.xml
echo         android:theme="@android:style/Theme.Material.Light"^> >> androidApp\src\main\AndroidManifest.xml
echo         ^<activity >> androidApp\src\main\AndroidManifest.xml
echo             android:name=".MainActivity" >> androidApp\src\main\AndroidManifest.xml
echo             android:exported="true"^> >> androidApp\src\main\AndroidManifest.xml
echo             ^<intent-filter^> >> androidApp\src\main\AndroidManifest.xml
echo                 ^<action android:name="android.intent.action.MAIN" /^> >> androidApp\src\main\AndroidManifest.xml
echo                 ^<category android:name="android.intent.category.LAUNCHER" /^> >> androidApp\src\main\AndroidManifest.xml
echo             ^</intent-filter^> >> androidApp\src\main\AndroidManifest.xml
echo         ^</activity^> >> androidApp\src\main\AndroidManifest.xml
echo     ^</application^> >> androidApp\src\main\AndroidManifest.xml
echo. >> androidApp\src\main\AndroidManifest.xml
echo ^</manifest^> >> androidApp\src\main\AndroidManifest.xml

:: Шаг 8: Очищаем кэш
echo Очищаем кэш Gradle...
if exist .gradle rmdir /s /q .gradle
if exist build rmdir /s /q build
if exist androidApp\build rmdir /s /q androidApp\build
if exist shared\build rmdir /s /q shared\build

echo.
echo Все исправления применены!
echo Теперь откройте проект в Android Studio и синхронизируйте Gradle.
pause