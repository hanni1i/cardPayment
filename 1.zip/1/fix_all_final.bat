@echo off
cd C:\Users\user\AndroidStudioProjects\1

echo Исправляем gradle.properties...
(
echo # Gradle JVM settings
echo org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m
echo.
echo # Android settings
echo android.useAndroidX=true
echo android.enableJetifier=false
echo.
echo # Kotlin settings
echo kotlin.code.style=official
echo kotlin.jvm.target.validation.mode=warning
echo.
echo # Performance settings
echo org.gradle.parallel=true
echo org.gradle.caching=true
echo org.gradle.daemon=true
) > gradle.properties

echo Исправляем gradle-wrapper.properties...
if not exist gradle\wrapper mkdir gradle\wrapper
(
echo distributionBase=GRADLE_USER_HOME
echo distributionPath=wrapper/dists
echo distributionUrl=https://services.gradle.org/distributions/gradle-8.10.2-bin.zip
echo zipStoreBase=GRADLE_USER_HOME
echo zipStorePath=wrapper/dists
) > gradle\wrapper\gradle-wrapper.properties

echo Очищаем кэш...
if exist .gradle rmdir /s /q .gradle
if exist build rmdir /s /q build
if exist androidApp\build rmdir /s /q androidApp\build
if exist shared\build rmdir /s /q shared\build

echo.
echo Готово! Теперь откройте Android Studio.
pause