pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "1"

// Автоматическое определение существующих папок
if (file("androidApp").exists()) {
    include(":androidApp")
} else if (file("app").exists()) {
    include(":app")
}

include(":shared")