package com.example.a1.shared.model

/**
 * Состояние формы ввода данных карты
 */
data class CardFormState(
    val cardNumber: String = "",
    val cardHolderName: String = "",
    val expiryDate: String = "",
    val cvv: String = "",
    val isCardNumberError: Boolean = false,
    val isCardHolderNameError: Boolean = false,
    val isExpiryDateError: Boolean = false,
    val isCvvError: Boolean = false,
    val cardNumberErrorMessage: String? = null,
    val cardHolderNameErrorMessage: String? = null,
    val expiryDateErrorMessage: String? = null,
    val cvvErrorMessage: String? = null,
    val isButtonEnabled: Boolean = false
)

/**
 * Результат валидации
 */
sealed class ValidationResult {
    object Success : ValidationResult()
    data class Error(val message: String) : ValidationResult()
}