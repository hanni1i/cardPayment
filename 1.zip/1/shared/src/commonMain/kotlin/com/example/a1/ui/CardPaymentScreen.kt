package com.example.a1.shared.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.a1.shared.ui.components.CardTextField
import com.example.a1.shared.viewmodel.CardPaymentViewModel
import kotlin.random.Random

@Composable
fun CardPaymentScreen(
    viewModel: CardPaymentViewModel,
    theme: ThemeColors,
    onThemeSelected: (ThemeColors) -> Unit
) {
    val state = viewModel.state
    var showDialog by remember { mutableStateOf(false) }
    var isPaymentSuccess by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = theme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            ThemeSwitcher(
                currentTheme = theme,
                onThemeSelected = onThemeSelected,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(top = 16.dp, end = 16.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp)
                    .padding(top = 80.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "💳 Оплата картой",
                    fontSize = 28.sp,
                    color = theme.text,
                    modifier = Modifier.padding(bottom = 32.dp)
                )

                CardTextField(
                    value = state.cardNumber,
                    onValueChange = { viewModel.onCardNumberChange(it) },
                    label = "Номер карты",
                    placeholder = "1234 5678 9012 3456",
                    isError = state.isCardNumberError,
                    errorMessage = state.cardNumberErrorMessage,
                    keyboardType = KeyboardType.Number,
                    theme = theme
                )

                Spacer(modifier = Modifier.height(16.dp))

                CardTextField(
                    value = state.cardHolderName,
                    onValueChange = { viewModel.onCardHolderNameChange(it) },
                    label = "Имя владельца",
                    placeholder = "IVAN PETROV",
                    isError = state.isCardHolderNameError,
                    errorMessage = state.cardHolderNameErrorMessage,
                    keyboardType = KeyboardType.Text,
                    theme = theme
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CardTextField(
                        value = state.expiryDate,
                        onValueChange = { viewModel.onExpiryDateChange(it) },
                        label = "Срок действия",
                        placeholder = "MM/YY",
                        isError = state.isExpiryDateError,
                        errorMessage = state.expiryDateErrorMessage,
                        keyboardType = KeyboardType.Number,
                        modifier = Modifier.weight(1f),
                        theme = theme
                    )

                    CardTextField(
                        value = state.cvv,
                        onValueChange = { viewModel.onCvvChange(it) },
                        label = "CVV",
                        placeholder = "123",
                        isError = state.isCvvError,
                        errorMessage = state.cvvErrorMessage,
                        keyboardType = KeyboardType.Number,
                        modifier = Modifier.weight(1f),
                        theme = theme
                    )
                }

                Spacer(modifier = Modifier.height(32.dp))

                Button(
                    onClick = {
                        isPaymentSuccess = viewModel.validateAndSubmit() && Random.nextBoolean()
                        showDialog = true
                    },
                    enabled = state.isButtonEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (state.isButtonEnabled) theme.primary else Color.Gray
                    )
                ) {
                    Text(
                        "Подтвердить",
                        color = theme.buttonTextColor
                    )
                }
            }
        }

        if (showDialog) {
            PaymentResultDialog(
                isSuccess = isPaymentSuccess,
                onDismiss = { showDialog = false },
                onRetry = {
                    showDialog = false
                    isPaymentSuccess = viewModel.validateAndSubmit() && Random.nextBoolean()
                    showDialog = true
                },
                theme = theme
            )
        }
    }
}

@Composable
fun ThemeSwitcher(
    currentTheme: ThemeColors,
    onThemeSelected: (ThemeColors) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        Button(
            onClick = { expanded = true },
            modifier = Modifier
                .width(100.dp)
                .height(40.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = currentTheme.primary
            )
        ) {
            Text(
                text = "🎨",
                fontSize = 20.sp,
                color = currentTheme.buttonTextColor
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            allThemes.forEach { theme ->
                DropdownMenuItem(
                    text = {
                        Text(
                            text = theme.name,
                            color = Color.Black
                        )
                    },
                    onClick = {
                        onThemeSelected(theme)
                        expanded = false
                    }
                )
            }
        }
    }
}

@Composable
fun PaymentResultDialog(
    isSuccess: Boolean,
    onDismiss: () -> Unit,
    onRetry: () -> Unit,
    theme: ThemeColors
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = theme.dialogBackground
            ),
            border = BorderStroke(2.dp, theme.dialogBorder)
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isSuccess) {
                    Text(
                        text = "🎉✨💳",
                        fontSize = 48.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Text(
                        text = "Карта успешно подтверждена!",
                        fontSize = 20.sp,
                        color = theme.text,
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.dialogButton
                            )
                        ) {
                            Text("Закрыть", color = theme.buttonTextColor)
                        }

                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.dialogButton.copy(alpha = 0.7f)
                            )
                        ) {
                            Text("OK", color = theme.buttonTextColor)
                        }
                    }
                } else {
                    Text(
                        text = "❌",
                        fontSize = 48.sp,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Text(
                        text = "Ошибка подтверждения",
                        fontSize = 20.sp,
                        color = theme.text,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    Text(
                        text = "Попробуйте снова",
                        fontSize = 16.sp,
                        color = theme.text.copy(alpha = 0.7f),
                        modifier = Modifier.padding(bottom = 24.dp)
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.dialogButton.copy(alpha = 0.5f)
                            )
                        ) {
                            Text("Отмена", color = theme.buttonTextColor)
                        }

                        Button(
                            onClick = onRetry,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = theme.dialogButton
                            )
                        ) {
                            Text("Повторить", color = theme.buttonTextColor)
                        }
                    }
                }
            }
        }
    }
}