package com.example.a1.shared.ui

import androidx.compose.ui.graphics.Color

data class ThemeColors(
    val name: String,
    val primary: Color,
    val background: Color,
    val surface: Color,
    val text: Color,
    val dialogBackground: Color,
    val dialogButton: Color,
    val dialogBorder: Color,
    val buttonTextColor: Color
)

val PinkTheme = ThemeColors(
    name = "Розовая",
    primary = Color(0xFFE91E63),
    background = Color(0xFFFFB6C1),
    surface = Color(0xFFFFC0CB),
    text = Color(0xFFFFF0F5),
    dialogBackground = Color(0xFFFFC0CB),
    dialogButton = Color(0xFFE91E63),
    dialogBorder = Color(0xFFFF69B4),
    buttonTextColor = Color.White
)

val DarkTheme = ThemeColors(
    name = "Темная",
    primary = Color(0xFFBB86FC),
    background = Color(0xFF121212),
    surface = Color(0xFF1E1E1E),
    text = Color.White,
    dialogBackground = Color(0xFF2C2C2C),
    dialogButton = Color(0xFFBB86FC),
    dialogBorder = Color(0xFF03DAC6),
    buttonTextColor = Color.White
)

val LightTheme = ThemeColors(
    name = "Светлая",
    primary = Color(0xFF6200EE),
    background = Color(0xFFF5F5F5),
    surface = Color.White,
    text = Color.Black,
    dialogBackground = Color.White,
    dialogButton = Color(0xFF6200EE),
    dialogBorder = Color(0xFFB0B0B0),
    buttonTextColor = Color.White
)

val WhiteTheme = ThemeColors(
    name = "Белый фон",
    primary = Color.Black,
    background = Color.White,
    surface = Color(0xFFFAFAFA),
    text = Color.Black,
    dialogBackground = Color.White,
    dialogButton = Color.Black,
    dialogBorder = Color.LightGray,
    buttonTextColor = Color.White
)

val allThemes = listOf(PinkTheme, DarkTheme, LightTheme, WhiteTheme)