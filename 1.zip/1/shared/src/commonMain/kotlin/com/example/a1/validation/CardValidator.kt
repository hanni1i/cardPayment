package com.example.a1.shared.validation

import com.example.a1.shared.model.ValidationResult
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.todayIn

class CardValidator {

    fun validateCardNumber(number: String): ValidationResult {
        val cleanNumber = number.replace(" ", "")

        return when {
            cleanNumber.isEmpty() -> ValidationResult.Error("Номер карты обязателен")
            !cleanNumber.all { it.isDigit() } -> ValidationResult.Error("Только цифры")
            cleanNumber.length != 16 -> ValidationResult.Error("16 цифр")
            !isValidLuhn(cleanNumber) -> ValidationResult.Error("Неверный номер карты")
            else -> ValidationResult.Success
        }
    }

    fun validateCardHolderName(name: String): ValidationResult {
        return when {
            name.isBlank() -> ValidationResult.Error("Имя обязательно")
            !name.matches(Regex("^[a-zA-Z\\s]+$")) -> ValidationResult.Error("Только латиница")
            else -> ValidationResult.Success
        }
    }

    fun validateExpiryDate(expiry: String): ValidationResult {
        val cleanExpiry = expiry.replace("/", "")

        if (cleanExpiry.length != 4 || !cleanExpiry.all { it.isDigit() }) {
            return ValidationResult.Error("Формат MM/YY")
        }

        val month = cleanExpiry.substring(0, 2).toInt()
        val year = cleanExpiry.substring(2, 4).toInt()

        val currentDate = Clock.System.todayIn(TimeZone.currentSystemDefault())
        val currentMonth = currentDate.monthNumber
        val currentYear = currentDate.year % 100

        return when {
            month !in 1..12 -> ValidationResult.Error("Неверный месяц")
            year < currentYear -> ValidationResult.Error("Карта просрочена")
            year == currentYear && month < currentMonth -> ValidationResult.Error("Карта просрочена")
            else -> ValidationResult.Success
        }
    }

    fun validateCvv(cvv: String): ValidationResult {
        return when {
            cvv.isEmpty() -> ValidationResult.Error("CVV обязателен")
            cvv.length != 3 -> ValidationResult.Error("3 цифры")
            !cvv.all { it.isDigit() } -> ValidationResult.Error("Только цифры")
            else -> ValidationResult.Success
        }
    }

    private fun isValidLuhn(number: String): Boolean {
        var sum = 0
        var alternate = false
        for (i in number.length - 1 downTo 0) {
            var n = number[i].digitToInt()
            if (alternate) {
                n *= 2
                if (n > 9) {
                    n -= 9
                }
            }
            sum += n
            alternate = !alternate
        }
        return sum % 10 == 0
    }
}