package com.example.a1.shared.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.example.a1.shared.model.CardFormState
import com.example.a1.shared.model.ValidationResult
import com.example.a1.shared.validation.CardValidator

class CardPaymentViewModel {
    private val validator = CardValidator()

    var state by mutableStateOf(CardFormState())
        private set

    fun onCardNumberChange(number: String) {
        val formattedNumber = formatCardNumber(number)
        state = state.copy(cardNumber = formattedNumber)
        validateForm()
    }

    fun onCardHolderNameChange(name: String) {
        state = state.copy(cardHolderName = name)
        validateForm()
    }

    fun onExpiryDateChange(expiry: String) {
        val formattedExpiry = formatExpiryDate(expiry)
        state = state.copy(expiryDate = formattedExpiry)
        validateForm()
    }

    fun onCvvChange(cvv: String) {
        if (cvv.length <= 3 && (cvv.all { it.isDigit() } || cvv.isEmpty())) {
            state = state.copy(cvv = cvv)
            validateForm()
        }
    }

    fun validateAndSubmit(): Boolean {
        val cardNumberResult = validator.validateCardNumber(state.cardNumber)
        val holderNameResult = validator.validateCardHolderName(state.cardHolderName)
        val expiryDateResult = validator.validateExpiryDate(state.expiryDate)
        val cvvResult = validator.validateCvv(state.cvv)

        return cardNumberResult is ValidationResult.Success &&
                holderNameResult is ValidationResult.Success &&
                expiryDateResult is ValidationResult.Success &&
                cvvResult is ValidationResult.Success
    }

    private fun validateForm() {
        val cardNumberResult = validator.validateCardNumber(state.cardNumber)
        val holderNameResult = validator.validateCardHolderName(state.cardHolderName)
        val expiryDateResult = validator.validateExpiryDate(state.expiryDate)
        val cvvResult = validator.validateCvv(state.cvv)

        state = state.copy(
            isCardNumberError = cardNumberResult is ValidationResult.Error,
            isCardHolderNameError = holderNameResult is ValidationResult.Error,
            isExpiryDateError = expiryDateResult is ValidationResult.Error,
            isCvvError = cvvResult is ValidationResult.Error,
            cardNumberErrorMessage = (cardNumberResult as? ValidationResult.Error)?.message,
            cardHolderNameErrorMessage = (holderNameResult as? ValidationResult.Error)?.message,
            expiryDateErrorMessage = (expiryDateResult as? ValidationResult.Error)?.message,
            cvvErrorMessage = (cvvResult as? ValidationResult.Error)?.message,
            isButtonEnabled = cardNumberResult is ValidationResult.Success &&
                    holderNameResult is ValidationResult.Success &&
                    expiryDateResult is ValidationResult.Success &&
                    cvvResult is ValidationResult.Success
        )
    }

    private fun formatCardNumber(input: String): String {
        val digits = input.filter { it.isDigit() }.take(16)
        return buildString {
            for (i in digits.indices) {
                if (i > 0 && i % 4 == 0) append(' ')
                append(digits[i])
            }
        }
    }

    private fun formatExpiryDate(input: String): String {
        val digits = input.filter { it.isDigit() }.take(4)
        return when (digits.length) {
            0 -> ""
            1 -> digits
            2 -> digits
            else -> "${digits.substring(0, 2)}/${digits.substring(2)}"
        }
    }
}